import 'package:flutter/material.dart';
import '../services/api_service.dart';
import '../models/wurf.dart';
import '../models/messung.dart';

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key});

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  final api = ApiService();

  late Future<Map<String, dynamic>> _summaryF;
  late Future<List<Wurf>> _wurfeF;
  late Future<List<Messung>> _messungenF;

  @override
  void initState() {
    super.initState();
    _reload();
  }

  void _reload() {
    _summaryF = api.getSummary();
    _wurfeF = api.getWuerfe(limit: 10);
    _messungenF = api.getMessungen(limit: 15);
    setState(() {});
  }

  Future<void> _addDummy() async {
    // create one dummy throw and a dummy measurement for it
    final id = await api.createDummyWurf();
    await api.createDummyMessung(id);
    _reload();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('SmartDisc Dashboard'),
        actions: [
          IconButton(onPressed: _reload, icon: const Icon(Icons.refresh)),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _addDummy,
        icon: const Icon(Icons.add),
        label: const Text('Add dummy'),
      ),
      body: RefreshIndicator(
        onRefresh: () async => _reload(),
        child: ListView(
          padding: const EdgeInsets.all(12),
          children: [
            // --- Summary chips ---
            FutureBuilder<Map<String, dynamic>>(
              future: _summaryF,
              builder: (c, s) {
                if (s.connectionState != ConnectionState.done) {
                  return const LinearProgressIndicator();
                }
                final m = s.data ?? {};
                String fmt(num? n) => (n ?? 0).toStringAsFixed(2);
                return Wrap(
                  spacing: 12,
                  runSpacing: 8,
                  children: [
                    Chip(label: Text('samples: ${m['messungenCount'] ?? 0}')),
                    Chip(label: Text('v_max: ${fmt(m['geschwindigkeitMax'])}')),
                    Chip(label: Text('v_avg: ${fmt(m['geschwindigkeitAvg'])}')),
                    Chip(label: Text('d_max: ${fmt(m['entfernungMax'])} m')),
                    Chip(label: Text('d_avg: ${fmt(m['entfernungAvg'])} m')),
                  ],
                );
              },
            ),
            const SizedBox(height: 16),

            // --- Latest throws ---
            const Text('Latest throws', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            FutureBuilder<List<Wurf>>(
              future: _wurfeF,
              builder: (c, s) {
                if (s.connectionState != ConnectionState.done) {
                  return const Padding(
                    padding: EdgeInsets.symmetric(vertical: 24),
                    child: Center(child: CircularProgressIndicator()),
                  );
                }
                final list = s.data ?? [];
                if (list.isEmpty) return const ListTile(title: Text('No throws yet'));
                return Column(
                  children: list.map((w) {
                    return Card(
                      child: ListTile(
                        title: Text('Disc: ${w.scheibeId ?? '-'}  •  v=${w.geschwindigkeit ?? '-'}'),
                        subtitle: Text('d=${w.entfernung ?? '-'} m   •   ${w.erstelltAm ?? ''}'),
                        trailing: Text(w.id),
                      ),
                    );
                  }).toList(),
                );
              },
            ),
            const SizedBox(height: 16),

            // --- Latest measurements ---
            const Text('Latest measurements', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            FutureBuilder<List<Messung>>(
              future: _messungenF,
              builder: (c, s) {
                if (s.connectionState != ConnectionState.done) {
                  return const Padding(
                    padding: EdgeInsets.symmetric(vertical: 24),
                    child: Center(child: CircularProgressIndicator()),
                  );
                }
                final list = s.data ?? [];
                if (list.isEmpty) return const ListTile(title: Text('No measurements yet'));
                return Column(
                  children: list.map((m) {
                    return ListTile(
                      leading: const Icon(Icons.sensors),
                      title: Text('Wurf: ${m.wurfId} • t=${m.zeitpunkt}'),
                      subtitle: Text('ax=${m.ax ?? '-'}, ay=${m.ay ?? '-'}, az=${m.az ?? '-'}'),
                      trailing: Text(m.temperatur == null ? '' : '${m.temperatur}°C'),
                    );
                  }).toList(),
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}
